<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Create the single-row table that powers the homepage hero, statistics,
     * and the Rescue / Restore / Rehome mission cards.
     */
    public function up(): void
    {
        Schema::create('home', function (Blueprint $table) {
            $table->id();

            // Hero copy.
            $table->string('hero_title');
            $table->text('hero_description');

            // Organization statistics shown under the hero actions.
            $table->string('stat_rescued_value', 50);
            $table->string('stat_rescued_label', 100);
            $table->string('stat_placed_value', 50);
            $table->string('stat_placed_label', 100);
            $table->string('stat_support_value', 50);
            $table->string('stat_support_label', 100);

            // Mission cards.
            $table->string('rescue_title', 100);
            $table->text('rescue_description');
            $table->string('restore_title', 100);
            $table->text('restore_description');
            $table->string('rehome_title', 100);
            $table->text('rehome_description');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migration.
     */
    public function down(): void
    {
        Schema::dropIfExists('home');
    }
};
