<?php

namespace Database\Seeders;

use App\Models\Home;
use Illuminate\Database\Seeder;

class HomeSeeder extends Seeder
{
    /**
     * Seed the single homepage content row with the default copy.
     */
    public function run(): void
    {
        Home::updateOrCreate(
            ['id' => 1],
            Home::defaults(),
        );
    }
}
