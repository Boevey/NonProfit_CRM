<?php

namespace Database\Seeders;

use App\Models\Post;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the default administrator and a few local demo posts.
     */
    public function run(): void
    {
        // Homepage copy is real content, so seed it in every environment.
        $this->call(HomeSeeder::class);

        $admin = User::updateOrCreate(
            ['email' => env('ADMIN_EMAIL', 'admin@pawlyrescue.org')],
            [
                'name' => env('ADMIN_NAME', 'Pawly Administrator'),
                'password' => Hash::make(env('ADMIN_PASSWORD', 'password')),
                'is_admin' => true,
                'email_verified_at' => now(),
            ],
        );

        // Demo content keeps the CMS useful on a fresh local install. It is
        // intentionally skipped in production so real content is never mixed in.
        if (app()->environment('local', 'testing') && Post::query()->count() === 0) {
            $this->seedDemoPosts($admin);
        }
    }

    /**
     * Create a small set of published/draft posts for local development.
     */
    private function seedDemoPosts(User $admin): void
    {
        $posts = [
            [
                'title' => 'How We Help Rescue Dogs Heal',
                'slug' => 'how-we-help-rescue-dogs-heal',
                'excerpt' => 'From the first medical check to a calm foster home, here is what a rescue journey looks like.',
                'featured_image' => 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=1200&q=80',
                'status' => Post::STATUS_PUBLISHED,
                'published_at' => now()->subDays(6),
                'content' => <<<'MARKDOWN'
## A second chance starts with safety

Every dog that arrives at Pawly begins with a simple promise: you are safe now.

Our team starts with a full medical assessment, a quiet space to rest, and a routine that helps each dog feel secure. Some need surgery. Some need patience. All of them need someone to believe in them.

### The first 72 hours

- A health check and vaccination review
- A calm foster placement with experienced volunteers
- Slow introductions to food, walks, and human touch

> Rescue is not a moment. It is a series of small, consistent acts of care.

Once a dog is stable, we build a personalized recovery plan and begin matching them with families who understand their needs.
MARKDOWN,
            ],
            [
                'title' => 'What to Expect When You Adopt',
                'slug' => 'what-to-expect-when-you-adopt',
                'excerpt' => 'Adoption is a partnership. Here is how we support families before, during, and after pickup day.',
                'featured_image' => 'https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=1200&q=80',
                'status' => Post::STATUS_PUBLISHED,
                'published_at' => now()->subDays(18),
                'content' => <<<'MARKDOWN'
## More than a handoff

Adopting a rescue dog is one of the most rewarding things you can do, but it works best when everyone is prepared.

### Before adoption

We talk through your home, schedule, and experience with dogs. This is not a test. It is a conversation that helps us make a lasting match.

### The first week

- Keep routines simple and predictable
- Give your new dog a quiet place to decompress
- Introduce new people and pets gradually

### Ongoing support

Our volunteers remain available after adoption. If something feels difficult, reach out. A small adjustment early on can make a big difference.
MARKDOWN,
            ],
            [
                'title' => 'Volunteer Spotlight: The Foster Network',
                'slug' => 'volunteer-spotlight-the-foster-network',
                'excerpt' => 'Meet the families who open their homes and give rescue dogs the time they need to trust again.',
                'featured_image' => 'https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?auto=format&fit=crop&w=1200&q=80',
                'status' => Post::STATUS_PUBLISHED,
                'published_at' => now()->subDays(32),
                'content' => <<<'MARKDOWN'
## The quiet heroes of rescue

Foster families are the heart of our work. They provide the calm, consistent environment that helps dogs learn that home is a safe place.

### A day in the life

Fostering is not about having a perfect house. It is about showing up with patience, keeping a routine, and celebrating small wins.

- A shy dog taking food from your hand
- A first relaxed nap on a soft bed
- A tail wag at the door

Those moments are the building blocks of recovery. If you have room in your home and heart, we would love to hear from you.
MARKDOWN,
            ],
            [
                'title' => 'Planning a Calm First Week at Home',
                'slug' => 'planning-a-calm-first-week-at-home',
                'excerpt' => 'A draft checklist for new adopters: supplies, routines, and quiet spaces.',
                'featured_image' => null,
                'status' => Post::STATUS_DRAFT,
                'published_at' => null,
                'content' => <<<'MARKDOWN'
## A gentle start

This draft will become a practical checklist for the first seven days after adoption.

- Prepare a quiet space
- Buy the right food
- Schedule a vet visit
- Keep introductions slow
MARKDOWN,
            ],
        ];

        foreach ($posts as $post) {
            Post::updateOrCreate(
                ['slug' => $post['slug']],
                [...$post, 'user_id' => $admin->id],
            );
        }
    }
}
