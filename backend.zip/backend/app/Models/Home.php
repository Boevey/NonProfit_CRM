<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Home extends Model
{
    /**
     * The homepage content is stored as a single row in the "home" table.
     *
     * @var string
     */
    protected $table = 'home';

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'hero_title',
        'hero_description',
        'stat_rescued_value',
        'stat_rescued_label',
        'stat_placed_value',
        'stat_placed_label',
        'stat_support_value',
        'stat_support_label',
        'rescue_title',
        'rescue_description',
        'restore_title',
        'restore_description',
        'rehome_title',
        'rehome_description',
    ];

    /**
     * The content used when the table is empty or a fresh install runs.
     *
     * @return array<string, string>
     */
    public static function defaults(): array
    {
        return [
            'hero_title' => 'We rescue dogs and help them find home.',
            'hero_description' => 'Pawly is a modern dog rescue nonprofit focused on safe shelter, compassionate care, and long-term adoption support for vulnerable dogs.',
            'stat_rescued_value' => '2.4k+',
            'stat_rescued_label' => 'Dogs rescued',
            'stat_placed_value' => '94%',
            'stat_placed_label' => 'Placed home',
            'stat_support_value' => '24/7',
            'stat_support_label' => 'Care support',
            'rescue_title' => 'Rescue',
            'rescue_description' => 'We bring in dogs in urgent need and provide immediate safety and medical care.',
            'restore_title' => 'Restore',
            'restore_description' => 'Our foster community helps each dog heal physically and emotionally in a calm home.',
            'rehome_title' => 'Rehome',
            'rehome_description' => 'We match every dog with a loving family using thoughtful, lasting adoption support.',
        ];
    }

    /**
     * Return the homepage content, creating the default row when missing.
     */
    public static function current(): self
    {
        return static::query()->first() ?? static::create(static::defaults());
    }
}
