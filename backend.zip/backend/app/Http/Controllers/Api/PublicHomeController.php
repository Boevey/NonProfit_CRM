<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\HomeResource;
use App\Models\Home;

class PublicHomeController extends Controller
{
    /**
     * Return the homepage content used by the public marketing site.
     */
    public function show(): HomeResource
    {
        return new HomeResource(Home::current());
    }
}
