<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PostResource;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class PublicBlogController extends Controller
{
    /**
     * Paginated list of published posts, newest first.
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $perPage = min(max($request->integer('per_page', 9), 1), 50);

        $posts = Post::query()
            ->published()
            ->with('author:id,name')
            ->when($request->filled('q'), function ($query) use ($request) {
                $search = '%'.$request->string('q')->trim().'%';

                $query->where(function ($query) use ($search) {
                    $query->where('title', 'like', $search)
                        ->orWhere('excerpt', 'like', $search);
                });
            })
            ->latest('published_at')
            ->paginate($perPage)
            ->withQueryString();

        return PostResource::collection($posts);
    }

    /**
     * Show a single published post by slug.
     */
    public function show(Post $post): PostResource
    {
        abort_unless($post->isPublished(), 404);

        $post->load('author:id,name');

        return new PostResource($post);
    }
}
