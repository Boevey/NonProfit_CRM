<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateHomeRequest;
use App\Http\Resources\HomeResource;
use App\Models\Home;

class AdminHomeController extends Controller
{
    /**
     * Return the current homepage content for the CMS editor.
     */
    public function show(): HomeResource
    {
        return new HomeResource(Home::current());
    }

    /**
     * Persist edits to the single homepage content row.
     */
    public function update(UpdateHomeRequest $request): HomeResource
    {
        $home = Home::current();

        $home->update($request->validated());

        return new HomeResource($home->refresh());
    }
}
