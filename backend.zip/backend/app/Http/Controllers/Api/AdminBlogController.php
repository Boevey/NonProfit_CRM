<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePostRequest;
use App\Http\Requests\UpdatePostRequest;
use App\Http\Resources\PostResource;
use App\Models\Post;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class AdminBlogController extends Controller
{
    /**
     * Paginated list of every post, including drafts.
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $perPage = min(max($request->integer('per_page', 10), 1), 100);

        $posts = Post::query()
            ->with('author:id,name')
            ->when($request->filled('status'), function ($query) use ($request) {
                $query->where('status', $request->string('status'));
            })
            ->when($request->filled('q'), function ($query) use ($request) {
                $search = '%'.$request->string('q')->trim().'%';

                $query->where(function ($query) use ($search) {
                    $query->where('title', 'like', $search)
                        ->orWhere('slug', 'like', $search);
                });
            })
            ->latest('updated_at')
            ->paginate($perPage)
            ->withQueryString();

        return PostResource::collection($posts);
    }

    /**
     * Create a post and persist an optional featured image.
     */
    public function store(StorePostRequest $request): JsonResponse
    {
        $data = Arr::except($request->validated(), ['featured_image', 'remove_featured_image']);

        $data['user_id'] = $request->user()->id;
        $data['featured_image'] = $request->storeFeaturedImage();
        $data['published_at'] = $this->resolvePublishedAt($data['status'], $data['published_at'] ?? null);

        $post = Post::create($data);

        return (new PostResource($post->load('author:id,name')))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    /**
     * Show a single post for the editor.
     */
    public function show(Post $post): PostResource
    {
        $post->load('author:id,name');

        return new PostResource($post);
    }

    /**
     * Update a post, replacing or removing its featured image as needed.
     */
    public function update(UpdatePostRequest $request, Post $post): PostResource
    {
        $data = Arr::except($request->validated(), ['featured_image', 'remove_featured_image']);

        $status = $data['status'] ?? $post->status;
        $publishedAt = array_key_exists('published_at', $data)
            ? $data['published_at']
            : $post->published_at;

        $data['published_at'] = $this->resolvePublishedAt($status, $publishedAt, $post);

        if ($request->hasFile('featured_image')) {
            $this->deleteFeaturedImage($post->featured_image);
            $data['featured_image'] = $request->storeFeaturedImage();
        } elseif ($request->wantsToRemoveFeaturedImage()) {
            $this->deleteFeaturedImage($post->featured_image);
            $data['featured_image'] = null;
        }

        $post->update($data);

        return new PostResource($post->load('author:id,name'));
    }

    /**
     * Delete a post and its uploaded image.
     */
    public function destroy(Post $post): Response
    {
        $this->deleteFeaturedImage($post->featured_image);

        $post->delete();

        return response()->noContent();
    }

    /**
     * Drafts never have a publish date. Published posts default to now.
     */
    private function resolvePublishedAt(string $status, mixed $publishedAt, ?Post $post = null): ?Carbon
    {
        if ($status !== Post::STATUS_PUBLISHED) {
            return null;
        }

        if ($publishedAt !== null && $publishedAt !== '') {
            return Carbon::parse($publishedAt);
        }

        return $post?->published_at ?? now();
    }

    /**
     * Remove a local upload, but never delete external image URLs.
     */
    private function deleteFeaturedImage(?string $path): void
    {
        if (! $path || Str::startsWith($path, ['http://', 'https://'])) {
            return;
        }

        Storage::disk('public')->delete($path);
    }
}
