<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateHomeRequest extends FormRequest
{
    /**
     * Only administrators may edit homepage content.
     */
    public function authorize(): bool
    {
        return $this->user()?->isAdmin() === true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'hero_title' => ['required', 'string', 'max:255'],
            'hero_description' => ['required', 'string', 'max:1000'],

            'stat_rescued_value' => ['required', 'string', 'max:50'],
            'stat_rescued_label' => ['required', 'string', 'max:100'],
            'stat_placed_value' => ['required', 'string', 'max:50'],
            'stat_placed_label' => ['required', 'string', 'max:100'],
            'stat_support_value' => ['required', 'string', 'max:50'],
            'stat_support_label' => ['required', 'string', 'max:100'],

            'rescue_title' => ['required', 'string', 'max:100'],
            'rescue_description' => ['required', 'string', 'max:500'],
            'restore_title' => ['required', 'string', 'max:100'],
            'restore_description' => ['required', 'string', 'max:500'],
            'rehome_title' => ['required', 'string', 'max:100'],
            'rehome_description' => ['required', 'string', 'max:500'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'hero_title.required' => 'Add a headline for the homepage hero.',
            'hero_description.required' => 'Add a short description for the homepage hero.',
            'rescue_description.required' => 'Describe the Rescue card.',
            'restore_description.required' => 'Describe the Restore card.',
            'rehome_description.required' => 'Describe the Rehome card.',
        ];
    }
}
