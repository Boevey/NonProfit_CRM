<?php

namespace App\Http\Requests;

use App\Http\Requests\Concerns\GeneratesUniqueSlug;
use App\Http\Requests\Concerns\HandlesFeaturedImage;
use App\Models\Post;
use Illuminate\Foundation\Http\FormRequest;

class UpdatePostRequest extends FormRequest
{
    use GeneratesUniqueSlug, HandlesFeaturedImage;

    /**
     * Only administrators may update posts.
     */
    public function authorize(): bool
    {
        return $this->user()?->isAdmin() === true;
    }

    /**
     * Re-slug only when the editor sent a title or slug, and ignore the
     * current post so its slug does not gain a new suffix on every save.
     */
    protected function prepareForValidation(): void
    {
        $post = $this->route('post');
        $ignoreId = $post instanceof Post ? $post->getKey() : null;

        if ($this->has('title') || $this->has('slug')) {
            $this->merge([
                'slug' => $this->uniqueSlug($this->slugFromInput(), $ignoreId),
            ]);
        }

        if ($this->has('status')) {
            $this->merge(['status' => $this->input('status')]);
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $post = $this->route('post');

        return [
            'title' => ['sometimes', 'required', 'string', 'max:255'],
            'slug' => [
                'sometimes',
                'required',
                'string',
                'max:255',
                'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/',
                'unique:posts,slug,'.($post instanceof Post ? $post->getKey() : 'NULL'),
            ],
            'excerpt' => ['sometimes', 'nullable', 'string', 'max:500'],
            'content' => ['sometimes', 'required', 'string'],
            'featured_image' => ['sometimes', 'nullable', 'image', 'mimes:jpg,jpeg,png,webp,gif', 'max:5120'],
            'remove_featured_image' => ['sometimes', 'boolean'],
            'status' => ['sometimes', 'required', 'in:draft,published'],
            'published_at' => ['sometimes', 'nullable', 'date'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'title.required' => 'Give the post a title.',
            'content.required' => 'Write some content before saving the post.',
            'status.in' => 'The status must be either draft or published.',
            'featured_image.image' => 'The featured image must be a valid image file.',
            'featured_image.mimes' => 'Use a JPG, PNG, WebP, or GIF image.',
            'featured_image.max' => 'The featured image may not be larger than 5 MB.',
            'slug.unique' => 'That slug is already in use. Try a different title.',
        ];
    }
}
