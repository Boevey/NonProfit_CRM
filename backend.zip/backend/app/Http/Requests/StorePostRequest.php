<?php

namespace App\Http\Requests;

use App\Http\Requests\Concerns\GeneratesUniqueSlug;
use App\Http\Requests\Concerns\HandlesFeaturedImage;
use App\Models\Post;
use Illuminate\Foundation\Http\FormRequest;

class StorePostRequest extends FormRequest
{
    use GeneratesUniqueSlug, HandlesFeaturedImage;

    /**
     * Only administrators may create posts.
     */
    public function authorize(): bool
    {
        return $this->user()?->isAdmin() === true;
    }

    /**
     * Normalize the slug and default the status before validation runs.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'slug' => $this->uniqueSlug($this->slugFromInput()),
            'status' => $this->input('status', Post::STATUS_DRAFT),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:255'],
            'slug' => ['required', 'string', 'max:255', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'unique:posts,slug'],
            'excerpt' => ['nullable', 'string', 'max:500'],
            'content' => ['required', 'string'],
            'featured_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp,gif', 'max:5120'],
            'status' => ['required', 'in:draft,published'],
            'published_at' => ['nullable', 'date'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'title.required' => 'Give the post a title.',
            'content.required' => 'Write some content before saving the post.',
            'status.in' => 'The status must be either draft or published.',
            'featured_image.image' => 'The featured image must be a valid image file.',
            'featured_image.mimes' => 'Use a JPG, PNG, WebP, or GIF image.',
            'featured_image.max' => 'The featured image may not be larger than 5 MB.',
            'slug.unique' => 'That slug is already in use. Try a different title.',
        ];
    }
}
