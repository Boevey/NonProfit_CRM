<?php

namespace App\Http\Requests\Concerns;

use App\Models\Post;
use Illuminate\Support\Str;

trait GeneratesUniqueSlug
{
    /**
     * Build a URL-safe base slug from the submitted slug or title.
     */
    protected function slugFromInput(): string
    {
        $source = (string) ($this->input('slug') ?: $this->input('title', ''));
        $slug = Str::slug($source);

        return $slug !== '' ? $slug : 'post';
    }

    /**
     * Append -2, -3, ... until the slug is unique (optionally ignoring a post).
     */
    protected function uniqueSlug(string $base, ?int $ignoreId = null): string
    {
        $slug = $base;
        $suffix = 2;

        while ($this->slugExists($slug, $ignoreId)) {
            $slug = $base.'-'.$suffix;
            $suffix++;
        }

        return $slug;
    }

    private function slugExists(string $slug, ?int $ignoreId): bool
    {
        return Post::query()
            ->where('slug', $slug)
            ->when($ignoreId !== null, fn ($query) => $query->where('id', '!=', $ignoreId))
            ->exists();
    }
}
