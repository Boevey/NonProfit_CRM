<?php

namespace App\Http\Requests\Concerns;

trait HandlesFeaturedImage
{
    /**
     * Store an uploaded featured image on the public disk.
     *
     * Files land in storage/app/public/blogs and are exposed through the
     * public/storage symlink created by `php artisan storage:link`.
     */
    public function storeFeaturedImage(): ?string
    {
        if (! $this->hasFile('featured_image')) {
            return null;
        }

        return $this->file('featured_image')->store('blogs', 'public');
    }

    /**
     * Whether the editor explicitly asked to remove the current image.
     */
    public function wantsToRemoveFeaturedImage(): bool
    {
        return $this->boolean('remove_featured_image');
    }
}
