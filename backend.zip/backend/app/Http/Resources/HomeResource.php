<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class HomeResource extends JsonResource
{
    /**
     * Transform the homepage content into a consistent API payload.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'hero_title' => $this->hero_title,
            'hero_description' => $this->hero_description,
            'stat_rescued_value' => $this->stat_rescued_value,
            'stat_rescued_label' => $this->stat_rescued_label,
            'stat_placed_value' => $this->stat_placed_value,
            'stat_placed_label' => $this->stat_placed_label,
            'stat_support_value' => $this->stat_support_value,
            'stat_support_label' => $this->stat_support_label,
            'rescue_title' => $this->rescue_title,
            'rescue_description' => $this->rescue_description,
            'restore_title' => $this->restore_title,
            'restore_description' => $this->restore_description,
            'rehome_title' => $this->rehome_title,
            'rehome_description' => $this->rehome_description,
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
