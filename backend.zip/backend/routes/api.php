<?php

use App\Http\Controllers\Api\AdminBlogController;
use App\Http\Controllers\Api\AdminHomeController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PublicBlogController;
use App\Http\Controllers\Api\PublicHomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Public read-only blog endpoints are available to everyone. Authentication
| and every write operation are protected by Sanctum + the admin middleware.
|
*/

Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);
});

// Public homepage content.
Route::get('/home', [PublicHomeController::class, 'show']);

// Public blog (published posts only).
Route::get('/blogs', [PublicBlogController::class, 'index']);
Route::get('/blogs/{post:slug}', [PublicBlogController::class, 'show']);

// Admin CMS (draft + published posts).
Route::middleware(['auth:sanctum', 'admin'])
    ->prefix('admin')
    ->group(function () {
        Route::get('/home', [AdminHomeController::class, 'show']);
        Route::match(['put', 'patch'], '/home', [AdminHomeController::class, 'update']);

        Route::get('/blogs', [AdminBlogController::class, 'index']);
        Route::post('/blogs', [AdminBlogController::class, 'store']);
        Route::get('/blogs/{post}', [AdminBlogController::class, 'show']);
        Route::match(['put', 'patch'], '/blogs/{post}', [AdminBlogController::class, 'update']);
        Route::delete('/blogs/{post}', [AdminBlogController::class, 'destroy']);
    });
